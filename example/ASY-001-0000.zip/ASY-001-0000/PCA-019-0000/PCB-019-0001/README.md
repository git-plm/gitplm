This directory simulates the PCB output required to manufacture a bare PCB board
-- typically the gerbers, etc.
